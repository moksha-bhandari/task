// Chart for activities (Weekly Product Sales)
const ctx = document.getElementById('activityChart').getContext('2d');
const activityChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'], // Labels for the weeks
        datasets: [{
            label: 'Products Sold',
            data: [100, 150, 120, 180], // Sample data for products sold per week
            borderColor: 'rgba(255, 99, 132, 1)', // Line color
            backgroundColor: 'rgba(255, 99, 132, 0.2)', // Fill color
            fill: true, // Fill under the line
            tension: 0.3 // Line smoothness
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            tooltip: {
                mode: 'index',
                intersect: false,
            },
        },
        scales: {
            x: {
                title: {
                    display: true,
                    text: 'Weeks'
                }
            },
            y: {
                title: {
                    display: true,
                    text: 'Products Sold'
                },
                beginAtZero: true
            }
        }
    }
});

// Pie chart for Top Products
const topProductsCtx = document.getElementById('topProductsChart').getContext('2d');
const topProductsChart = new Chart(topProductsCtx, {
    type: 'pie',
    data: {
        labels: ['Basic Tees', 'Custom Short Pants', 'Super Hoodies'], // Labels for the products
        datasets: [{
            data: [45, 25, 30], // Sample data representing percentage sales for each product
            backgroundColor: [
                'rgb(54, 162, 235)',  // Blue for Basic Tees
                'rgb(255, 205, 86)',  // Yellow for Custom Short Pants
                'rgb(255, 99, 132)'   // Red for Super Hoodies
            ],
            borderColor: [
                'rgb(54, 162, 235)',
                'rgb(255, 205, 86)',
                'rgb(255, 99, 132)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            tooltip: {
                callbacks: {
                    label: function(tooltipItem) {
                        return tooltipItem.label + ': ' + tooltipItem.raw + '%';
                    }
                }
            }
        }
    }
});

// Handle Add Profile form submission
document.getElementById('add-profile-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const formValues = Object.fromEntries(formData.entries());

    // Here, you can handle the data as needed (e.g., send it to a server)
    console.log('Profile Added:', formValues);

    alert('Profile has been added successfully!');
    // Optionally, reset the form or navigate to another page
    this.reset();
    // Redirect to dashboard or other page
    window.location.href = 'dashboard.html';
});

// Handle Sign-In form (if needed in the main page)
document.getElementById('sign-in-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = this.querySelector('input[type="text"]').value;
    const password = this.querySelector('input[type="password"]').value;
    
    // Example of validation and logic, here you could add real sign-in functionality
    if (username === 'admin' && password === 'password') {
        alert('Signed in successfully!');
        window.location.href = 'dashboard.html'; // Redirect to the dashboard page
    } else {
        alert('Invalid credentials');
    }
});
